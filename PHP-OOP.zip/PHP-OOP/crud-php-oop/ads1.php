<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">

  <title>Ad new Post</title>
</head>
<body>You are not logged in please login to add a new post
<a href="login.php">Login here!</a>
</body>