<?php
$conn=mysqli_connect("localhost","root","","post");
if ($conn) {
	if(isset($_POST["Login"])){
	session_start();
	$firstname=$_POST['firstname'];
	$lastname=$_POST['lastname'];
	if($firstname=='admin' && $lastname=='admin')
	{
		header('location:index1.php');
	}else{
	
	$sql="SELECT *from User where Fname='$firstname' AND Sname='$lastname'";
	$result=mysqli_query($conn,$sql);
	$count = mysqli_num_rows($result);
	if($count == 1){
		header('location:homepage.php');
	}
	else{
		echo "invalid firstname or firstname please register";
	
		
	}
}
}
}
else {
	echo "Datbase sconnection failed!!!!!";
}

