<?php 
  include "./includes/class-autoload.inc.php";

  $posts = new Posts();
  
  if(isset($_POST['submit'])) {
    $title = $_POST['post-title'];
    $body = $_POST['post-content'];
    $author = $_POST['post-author'];
  
    $posts->addPost($title, $body, $author);
  
    header("location: homepage.php?status=added");
  
  } else if($_GET['send'] === 'del') {
    $id = $_GET['id'];
    $posts->delPost($id);

    header("location: index1.php?status=deleted");
  } else if($_GET['send'] === 'update') {
    $id = $_GET['id'];

    $title = $_POST['post-title'];
    $body = $_POST['post-content'];
    $author = $_POST['post-author'];

    $posts->updatePost($id, $title, $body, $author);

    header("location:index1.php?status=updated");
  }
