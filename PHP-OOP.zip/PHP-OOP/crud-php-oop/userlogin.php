<?php 
$conn=mysqli_connect("localhost","root","","post");
if ($conn) {
	if(isset($_POST["register"])){
$age=$lastname=$firstname=$password="";
$age=$_POST['age'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$title=$_POST['title'];

$sql = "INSERT INTO `user`(`id`, `Fname`, `Sname`, `age`, `title`) VALUES ('','$firstname','$lastname','$age','$title')";
$result=mysqli_query($conn,$sql);
if ($result) {
	header('location:homepage.php');
}
else{
	echo "error in registration";
}
}
}
else {
	echo "Database connection failed!!!!!";
}


