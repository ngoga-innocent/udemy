## CRUD in php, This project creating using oop and pdo

Screenshoot for the project
![crud php oop pdo](./img/crud-php-oop.gif)