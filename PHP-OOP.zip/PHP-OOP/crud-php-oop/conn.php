<?php
$conn=mysqli_connect("localhost","root","","post");
if (!$conn) {
	echo "Datbase sconnection failed!!!!!";
}